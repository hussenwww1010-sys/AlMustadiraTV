المستديرة TV — ملفات مشروع Android

مهم: هذه الملفات تضاف إلى مستودع AlMustadiraTV الحالي، ولا تستبدل index.html أو data.json الموجودين.

المجلدات:
- android/ : مشروع Android الأصلي (Kotlin + Media3 ExoPlayer)
- .github/workflows/build-android.yml : بناء APK تلقائياً بواسطة GitHub Actions

طريقة الإضافة من الآيفون:
1) افتح https://github.com/hussenwww1010-sys/AlMustadiraTV
2) ارفع محتويات هذا الملف المضغوط إلى المستودع مع الحفاظ على المجلدات كما هي. لا ترفع مجلد AlMustadiraTV-Android الخارجي؛ ارفع ما بداخله.
3) يجب أن تكون المسارات النهائية مثل:
   android/settings.gradle.kts
   android/build.gradle.kts
   android/app/build.gradle.kts
   android/app/src/main/AndroidManifest.xml
   android/app/src/main/java/com/almustadira/tv/MainActivity.kt
   .github/workflows/build-android.yml
4) اضغط Commit changes.
5) افتح Actions ثم Build AlMustadira TV APK.
6) بعد نجاح البناء، افتح صفحة العملية ونزّل Artifact باسم AlMustadira-TV-APK.

إدارة القنوات:
التطبيق يقرأ data.json من رابط GitHub Pages الحالي:
https://hussenwww1010-sys.github.io/AlMustadiraTV/data.json
يدعم مصفوفة channels في المستوى الأعلى، وكذلك packages ثم channels داخل كل باقة. الحقول المفهومة: id, name, title, category, url, stream, logo, type, enabled, userAgent, referer.

تنبيهات:
- لازم رابط البث يكون متاحاً ومسموحاً لك باستخدامه. بعض الروابط قد تحتاج headers خاصة؛ userAgent وreferer محفوظان في البيانات حالياً لكن النسخة الأساسية لا تطبق referer مخصصاً أثناء التشغيل.
- إذا كان ملف data.json الحالي لا يحتوي على روابط قنوات ضمن channels أو packages[].channels، لن تظهر قنوات بالتطبيق إلى أن نضبط محلل JSON وفق البنية الفعلية.
- هذا ينتج APK تجريبياً موقّعاً بمفتاح debug. للتحديث فوق نسخة منشورة للجمهور نحتاج إعداد توقيع release ثابت.
- لم يتم تغيير ملفات الموقع الحالي بواسطة هذه الحزمة؛ أضف الملفات الجديدة فقط.
