package com.almustadira.tv

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.setPadding
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

private const val DATA_URL = "https://hussenwww1010-sys.github.io/AlMustadiraTV/data.json"
private const val PREFS = "almustadira_cache"
private const val CACHE_KEY = "data_json"

private data class TvChannel(
    val id: String,
    val name: String,
    val category: String,
    val url: String,
    val logo: String = "",
    val type: String = "",
    val userAgent: String = "",
    val referer: String = ""
)

class MainActivity : Activity() {
    private val io = Executors.newSingleThreadExecutor()
    private val channels = mutableListOf<TvChannel>()
    private lateinit var root: LinearLayout
    private lateinit var channelList: LinearLayout
    private lateinit var playerView: PlayerView
    private lateinit var statusText: TextView
    private var player: ExoPlayer? = null
    private var fullScreen = false

    private val bg = Color.rgb(6, 9, 24)
    private val panel = Color.rgb(17, 10, 44)
    private val cyan = Color.rgb(0, 229, 255)
    private val purple = Color.rgb(168, 85, 247)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        loadChannels()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "المستديرة  TV"
            textSize = 25f
            setTextColor(cyan)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
        }
        val subtitle = TextView(this).apply {
            text = "   |   SPORTS"
            textSize = 12f
            setTextColor(purple)
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(brand)
        header.addView(subtitle)
        root.addView(header, LinearLayout.LayoutParams(-1, dp(48)))

        statusText = TextView(this).apply {
            text = "جاري تحميل القنوات..."
            textSize = 14f
            setTextColor(white)
            setPadding(dp(8))
        }
        root.addView(statusText, LinearLayout.LayoutParams(-1, dp(40)))

        playerView = PlayerView(this).apply {
            useController = true
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            setBackgroundColor(Color.BLACK)
            setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
        }
        root.addView(playerView, LinearLayout.LayoutParams(-1, 0, 1.2f))

        val listTitle = TextView(this).apply {
            text = "القنوات الرياضية"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(purple)
            setPadding(0, dp(12), 0, dp(8))
        }
        root.addView(listTitle)

        val scroll = ScrollView(this).apply { isFillViewport = false }
        channelList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(8))
        }
        scroll.addView(channelList)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun loadChannels() {
        val cached = getSharedPreferences(PREFS, MODE_PRIVATE).getString(CACHE_KEY, null)
        if (!cached.isNullOrBlank()) parseAndShow(cached, "تم عرض القنوات المحفوظة — جاري التحديث")
        io.execute {
            try {
                val connection = (URL(DATA_URL).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 12000
                    readTimeout = 12000
                    requestMethod = "GET"
                    setRequestProperty("Cache-Control", "no-cache")
                }
                val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                connection.disconnect()
                JSONObject(body) // validate JSON before caching
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(CACHE_KEY, body).apply()
                runOnUiThread { parseAndShow(body, "تم تحديث القنوات") }
            } catch (e: Exception) {
                runOnUiThread {
                    if (channels.isEmpty()) statusText.text = "تعذر تحميل data.json. تحقق من الإنترنت وملف القنوات."
                    else statusText.text = "تعذر التحديث؛ تعمل آخر نسخة محفوظة."
                }
            }
        }
    }

    private fun parseAndShow(raw: String, status: String) {
        try {
            val json = JSONObject(raw)
            val found = mutableListOf<TvChannel>()
            val topChannels = json.optJSONArray("channels")
            if (topChannels != null) readChannelArray(topChannels, "القنوات", found)

            val packages = json.optJSONArray("packages")
            if (packages != null) {
                for (i in 0 until packages.length()) {
                    val pkg = packages.optJSONObject(i) ?: continue
                    val category = pkg.optString("name", pkg.optString("title", "القنوات"))
                    val arr = pkg.optJSONArray("channels") ?: continue
                    readChannelArray(arr, category, found)
                }
            }
            channels.clear()
            channels.addAll(found.distinctBy { if (it.id.isNotBlank()) it.id else it.url })
            statusText.text = if (channels.isEmpty()) "ماكو قنوات صالحة بملف data.json" else "$status • ${channels.size} قناة"
            renderChannels()
        } catch (_: Exception) {
            statusText.text = "تنسيق data.json غير صحيح"
        }
    }

    private fun readChannelArray(arr: JSONArray, defaultCategory: String, out: MutableList<TvChannel>) {
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            if (item.has("enabled") && !item.optBoolean("enabled", true)) continue
            val url = item.optString("url", item.optString("stream", "")).trim()
            if (url.isBlank()) continue
            out.add(
                TvChannel(
                    id = item.optString("id", "channel_$i"),
                    name = item.optString("name", item.optString("title", "قناة ${i + 1}")),
                    category = item.optString("category", defaultCategory),
                    url = url,
                    logo = item.optString("logo", ""),
                    type = item.optString("type", ""),
                    userAgent = item.optString("userAgent", ""),
                    referer = item.optString("referer", "")
                )
            )
        }
    }

    private fun renderChannels() {
        channelList.removeAllViews()
        if (channels.isEmpty()) {
            val empty = TextView(this).apply {
                text = "أضف روابط القنوات داخل data.json حتى تظهر هنا."
                setTextColor(white)
                textSize = 14f
            }
            channelList.addView(empty)
            return
        }
        channels.forEachIndexed { index, channel ->
            val button = Button(this).apply {
                text = "▶   ${channel.name}"
                textSize = 15f
                isAllCaps = false
                setTextColor(white)
                setBackgroundColor(if (index % 2 == 0) panel else Color.rgb(10, 18, 38))
                gravity = Gravity.CENTER_VERTICAL or Gravity.START
                setPadding(dp(14), dp(4), dp(14), dp(4))
                contentDescription = "تشغيل ${channel.name}"
                setOnClickListener { playChannel(channel) }
                setOnFocusChangeListener { v, focused ->
                    v.setBackgroundColor(if (focused) Color.rgb(0, 90, 105) else if (index % 2 == 0) panel else Color.rgb(10, 18, 38))
                }
            }
            val params = LinearLayout.LayoutParams(-1, dp(52))
            params.bottomMargin = dp(6)
            channelList.addView(button, params)
        }
        if (channels.isNotEmpty()) channelList.getChildAt(0)?.requestFocus()
    }

    private fun playChannel(channel: TvChannel) {
        try {
            if (player == null) {
                val httpFactory = DefaultHttpDataSource.Factory().apply {
                    setConnectTimeoutMs(15000)
                    setReadTimeoutMs(20000)
                    setAllowCrossProtocolRedirects(true)
                }
                player = ExoPlayer.Builder(this)
                    .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(httpFactory))
                    .build().also { exo ->
                        playerView.player = exo
                        exo.addListener(object : Player.Listener {
                            override fun onPlayerError(error: PlaybackException) {
                                Toast.makeText(this@MainActivity, "تعذر تشغيل البث: ${error.errorCodeName}", Toast.LENGTH_LONG).show()
                            }
                        })
                    }
            }
            val exo = player ?: return
            val itemBuilder = MediaItem.Builder().setUri(Uri.parse(channel.url))
            val lower = channel.url.lowercase()
            when {
                lower.contains(".m3u8") || channel.type.equals("hls", true) -> itemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8)
                lower.contains(".mpd") || channel.type.equals("dash", true) -> itemBuilder.setMimeType(MimeTypes.APPLICATION_MPD)
            }
            statusText.text = "جاري تشغيل: ${channel.name}"
            exo.setMediaItem(itemBuilder.build())
            exo.prepare()
            exo.playWhenReady = true
        } catch (e: Exception) {
            Toast.makeText(this, "رابط القناة غير صالح", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && fullScreen) {
            fullScreen = false
            playerView.layoutParams = LinearLayout.LayoutParams(-1, 0, 1.2f)
            for (i in 0 until root.childCount) root.getChildAt(i).visibility = View.VISIBLE
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER && playerView.hasFocus()) {
            toggleFullscreen()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun toggleFullscreen() {
        fullScreen = !fullScreen
        if (fullScreen) {
            for (i in 0 until root.childCount) if (root.getChildAt(i) !== playerView) root.getChildAt(i).visibility = View.GONE
            playerView.layoutParams = LinearLayout.LayoutParams(-1, -1)
            playerView.requestFocus()
        } else {
            for (i in 0 until root.childCount) root.getChildAt(i).visibility = View.VISIBLE
            playerView.layoutParams = LinearLayout.LayoutParams(-1, 0, 1.2f)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        playerView.player = null
        player?.release()
        player = null
        io.shutdownNow()
        super.onDestroy()
    }
}
